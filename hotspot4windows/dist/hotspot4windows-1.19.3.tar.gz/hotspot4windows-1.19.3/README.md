# hotspot4windows

Wireless hotspot Python package in Windows environment.If you like this package,
you can [follow me on Github](https://github.com/ying2002).

Thanks!:)

**About release notes, you can [click me](https://github.com/ying2002/hotspot4windows/wiki/Release-Notes)**

**Because of the problem of the package called "Getpass", this package only works in Windows CMD, in order that you can use  this package with pleasure, [click me to find solution](https://github.com/ying2002/hotspot4windows/wiki)**

## What's new in 1.19.3

Added quick setup module.

If you have any question, please mailto:

877259039@qq.com